To use your PWA:

#. Open the Odoo web app using a supported browser (See https://caniuse.com/?search=A2HS)
#. Open the browser options
#. Click on 'Add to Home screen' (or 'Install' in other browsers)

** Maybe you need refresh the page to load the service worker after using the option.
