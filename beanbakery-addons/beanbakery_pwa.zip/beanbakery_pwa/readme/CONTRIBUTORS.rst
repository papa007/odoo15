* `TAKOBI <https://takobi.online>`_:

  * Lorenzo Battistini

* `Tecnativa <https://tecnativa.com>`_:

  * Alexandre D. Díaz
  * João Marques
