## Module <partner_emails_history>

#### 16.10.2021
#### Version 15.0.1.0.0
#### ADD
- Initial Commit for partner_emails_history
