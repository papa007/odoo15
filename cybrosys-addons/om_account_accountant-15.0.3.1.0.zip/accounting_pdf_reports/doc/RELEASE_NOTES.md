## Module <accounting_pdf_reports>

#### 25.12.2021
#### Version 15.0.6.0.0
##### IMP
- filters like account, partner and analytic account

#### 14.12.2021
#### Version 15.0.5.0.0
##### IMP
- remove logger warning, same label
