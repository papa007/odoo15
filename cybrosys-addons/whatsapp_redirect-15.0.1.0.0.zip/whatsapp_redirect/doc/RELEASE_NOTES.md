## Module <whatsapp_redirect>

#### 26.11.2021
#### Version 15.0.1.0.0
##### ADD
- Initial commit for Send Whatsapp Message Module
