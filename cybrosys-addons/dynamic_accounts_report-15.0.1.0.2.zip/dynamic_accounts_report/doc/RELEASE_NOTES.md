## Module <dynamic_accounts_report>

#### 02.09.2021
#### Version 15.0.1.0.0
#### ADD
- Initial commit for Odoo 15 dynamic financial reports



#### 20.12.2021
#### Version 15.0.1.0.1
#### UPDT
- Translation issue and Calendar format issue

#### 15.01.2022
#### Version 15.0.1.0.2
#### UPDT
- Arabic Translation added